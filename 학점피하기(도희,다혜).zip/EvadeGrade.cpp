﻿#include <stdio.h>
#include <windows.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>
#include <iostream>
#define MapX 20
#define MapY 20

int map[MapY][MapX];

using namespace std;

void gotoxy(int x, int y)
{
	COORD pos = { x,y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
int ddongspeed(int *speed, int *score)
{//speed 컨트롤
	if (*score > 50) *speed = 200;
	if (*score > 150) *speed = 150;
	if (*score > 200) *speed = 100;
	if (*score > 250) *speed = 50;
	if (*score > 300)*speed = 25;
	return *speed;
}
void Mapline()
{//맵경계표시
	for (int i = 0; i < MapY + 1; i++)
	{
		gotoxy(MapX, i); printf("■\n");
	}
	gotoxy(0, MapY);
	for (int i = 0; i < MapX / 2; i++)printf("■");
}
void InitMap()
{
	for (int i = 0; i < MapY; i++)
	{
		for (int j = 0; j < MapX; j++)
		{
			map[i][j] = 0;
		}
	}
}
void PrintMap(int * P)
{
	for (int i = 0; i < MapY - 1; i++)
	{
		for (int j = 0; j < MapX; j++)
		{
			if (map[i][j] == 0) printf(" ");
			else if (map[i][j] == 1)printf("A");
			else if (map[i][j] == 2)printf("B");
			else if (map[i][j] == 3)printf("C");
			else if (map[i][j] == 4)printf("D");
			else if (map[i][j] == 5)printf("F");
		}
		printf("\n");
	}
	for (int j = 0; j < MapX; j++)
	{
		if (P[j] == 0) printf(" ");
		else if (P[j] == 1) printf("♀");
	}
}
void RowDownMap()
{
	for (int i = MapY - 1; i > 0; i--)
	{
		for (int j = 0; j < MapX; j++)
		{
			map[i][j] = map[i - 1][j];
		}
	}
	for (int j = 0; j < MapX; j++)
	{
		map[0][j] = 0;
	}
}
int CollisionDetection(int *score, int * P, int *life)
{                                //목숨, 점수 계산 함수
	for (int i = 0; i < MapX; i++)
	{
		if (map[MapY - 1][i] && P[i]) {
			if (map[MapY - 1][i] == 1) {// A 학점
				gotoxy(MapX + 2, 3);
				printf(" A학점 취득!! 생명 회복(+2)! ");
				*life += 2;
				gotoxy(MapX + 2, 0);
				printf("LIFE:                                         ");
				gotoxy(MapX + 2, 0);
				printf("LIFE:");
				for (unsigned int i = 0; i < *life; i++)
				{
					printf("♥");
					if (*life < 0) {
						break;
					}
				}
			}
			else if (map[MapY - 1][i] == 2) {// B 학점
				gotoxy(MapX + 2, 3);
				printf(" B학점 취득!! 생명 감소(-1)! ");
				*life -= 1;
				gotoxy(MapX + 2, 0);
				printf("LIFE:                                         ");
				gotoxy(MapX + 2, 0);
				printf("LIFE:");
				for (unsigned int i = 0; i < *life; i++)
				{
					printf("♥");
					if (*life < 0) {
						break;
					}
				}
			}
			else if (map[MapY - 1][i] == 3) {// C 학점
				gotoxy(MapX + 2, 3);
				printf(" C학점 취득!! 생명 감소(-1)! ");
				*life -= 2;
				gotoxy(MapX + 2, 0);
				printf("LIFE:                                         ");
				gotoxy(MapX + 2, 0);
				printf("LIFE:");
				for (unsigned int i = 0; i < *life; i++)
				{
					printf("♥");
					if (*life < 0) {
						break;
					}
				}
			}
			else if (map[MapY - 1][i] == 4) {// D 학점
				gotoxy(MapX + 2, 3);
				printf(" D학점 취득!! 생명 감소(-1)! ");
				*life -= 3;
				gotoxy(MapX + 2, 0);
				printf("LIFE:                                         ");
				gotoxy(MapX + 2, 0);
				printf("LIFE:");
				for (unsigned int i = 0; i < *life; i++)
				{
					printf("♥");
					if (*life < 0) {
						break;
					}
				}
			}
			else if (map[MapY - 1][i] == 5) {// F 학점 즉시게임종료 
				*life -= 1000;
			}
		}// 학점이 유저와 충돌시
		else if (map[MapY - 1][i] == 2 && P[i] != 1) {//B가 닿을때
			*score += 1;
		}
		else if (map[MapY - 1][i] == 3 && P[i] != 1) {//C가 닿을때
			*score += 2;
		}
		else if (map[MapY - 1][i] == 4 && P[i] != 1) {//D가 닿을때
			*score += 3;
		}
		else if (map[MapY - 1][i] == 5 && P[i] != 1) {//F가 닿을때
			*score += 4;
		}//학점이 땅에 충돌시
	}
	if (*life < 0) {
		return 1;
	}
	return 0;
}
int main()
{
	int Person[MapX] = { 0, };
	int Position;
	int ch;
	int stage = 1;
	int score = 0;
	int life = 5;
	int speed = 300;

	int PerPosition = (int)(MapX / 2.0);
	InitMap();
	Mapline();

	gotoxy(MapX + 2, 0);
	printf("LIFE:♥♥♥♥♥");

	srand((unsigned)time(NULL));

	Person[PerPosition] = 1;
	for (;;)
	{
		RowDownMap();
		for (int i = 0; i < rand() % 4; i++)// 라인당 오브젝트 0~3개 나오도록
		{
			int num = rand() % 6;
			Position = rand() % MapX;
			map[0][Position] = num;
		}
		if (_kbhit())
		{
			ch = _getch();
			ch = _getch();
			if (ch == 75 && PerPosition > 0)
			{
				Person[PerPosition] = 0;
				PerPosition--;
				Person[PerPosition] = 1;
			}
			else if (ch == 77 && PerPosition < MapX - 1)
			{
				Person[PerPosition] = 0;
				PerPosition++;
				Person[PerPosition] = 1;
			}
		}
		gotoxy(0, 0);
		PrintMap(Person);
		if (CollisionDetection(&score, Person, &life))break;
		ddongspeed(&speed, &score);
		Sleep(speed);
		//목숨,스테이지,점수 출력
		gotoxy(MapX + 2, 1);
		printf("STAGE:%d", (score / 50) + 1);
		gotoxy(MapX + 2, 2);
		printf("score:%d", score);
	}
	system("cls");       //최종 점수 출력
	gotoxy(MapX / 3, MapY / 4);
	printf("Game Over!!\n");
	printf("\t邕당신의 점수는 %d점입니다邕\n\n", score);//\t tap
}